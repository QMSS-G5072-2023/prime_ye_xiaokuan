# prime_xy2598

A Python package developed by Xiaokuan Ye, identifing a prime

## Installation

```bash
$ pip install prime_xy2598
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`prime_xy2598` was created by XiaoKuan Ye. It is licensed under the terms of the MIT license.

## Credits

`prime_xy2598` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
